package proxy;
//this is just a component
public interface WebPage {
    void render(String url);

}
