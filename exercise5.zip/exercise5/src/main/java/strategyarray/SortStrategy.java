package strategyarray;

// strategy interface that defines the sort method
public interface SortStrategy {
    void sort(int[] numbers);
}

