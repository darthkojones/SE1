package mci.at;

public interface PaymentMethod {
    void pay(double amount);
}

