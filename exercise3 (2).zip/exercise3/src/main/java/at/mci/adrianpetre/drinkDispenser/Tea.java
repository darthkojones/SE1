package at.mci.adrianpetre.drinkDispenser;

public class Tea implements Drink{

    
    @Override
    public void dispense() {
    System.out.println("Dispensing tea");
}

}
