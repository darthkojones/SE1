package at.mci.adrianpetre.drinkDispenser;


public class Coffee implements Drink{

    @Override
    public void dispense() {
    System.out.println("Dispensing coffee");
}

}
