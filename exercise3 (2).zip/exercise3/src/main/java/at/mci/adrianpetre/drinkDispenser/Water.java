package at.mci.adrianpetre.drinkDispenser;

public class Water implements Drink{

    
    @Override
    public void dispense() {
    System.out.println("Dispensing water");
}

}
